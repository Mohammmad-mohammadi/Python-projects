#!/usr/bin/env python3
"""
music_browser.py

Read-only Flask app to browse the offline music DB (no network).
Usage:
  python music_browser.py --db music_ultimate_full.db --host 127.0.0.1 --port 5000

This app only reads from the SQLite DB and provides filtering and CSV export.
"""
import argparse, sqlite3
from flask import Flask, request, render_template_string, Response

FLASK_TEMPLATE = """
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Music Browser</title>
<style>body{font-family:Arial;margin:20px}table{border-collapse:collapse;width:100%}th,td{padding:8px;border:1px solid #ddd;text-align:left}th{background:#f2f2f2}</style>
</head>
<body>
<h2>Music Browser (Offline)</h2>
<form method="get">
  <label>Composer: <input name="composer" value="{{request.args.get('composer','')}}" /></label>
  <label>Emotion:
    <select name="emotion">
      <option value="">(any)</option>
      {% for e in emotions %}
        <option value="{{e}}" {% if request.args.get('emotion')==e %}selected{% endif %}>{{e}}</option>
      {% endfor %}
    </select>
  </label>
  <label>Min difficulty: <input type="number" name="min_d" value="{{request.args.get('min_d','')}}" /></label>
  <label>Type: <input name="type" value="{{request.args.get('type','')}}" /></label>
  <label>Scale: <input name="scale" value="{{request.args.get('scale','')}}" /></label>
  <label>Search: <input name="q" value="{{request.args.get('q','')}}" /></label>
  <label>Sort:
    <select name="sort">
      <option value="">(default)</option>
      <option value="difficulty_desc" {% if request.args.get('sort')=='difficulty_desc' %}selected{% endif %}>Difficulty ↓</option>
      <option value="difficulty_asc" {% if request.args.get('sort')=='difficulty_asc' %}selected{% endif %}>Difficulty ↑</option>
      <option value="composer" {% if request.args.get('sort')=='composer' %}selected{% endif %}>Composer</option>
    </select>
  </label>
  <button>Filter</button>
  <a href="/export?{{request.query_string.decode('utf-8')}}">Export CSV</a>
</form>
<p>Showing {{total}} results (page {{page}})</p>
<table>
<tr><th>#</th><th>Title</th><th>Composer</th><th>Emotion</th><th>Difficulty</th><th>Type</th><th>Scale</th></tr>
{% for r in results %}
<tr>
  <td>{{r['piece_id']}}</td>
  <td>{{r['title']}}</td>
  <td>{{r['full_name']}}</td>
  <td>{{r['emotion_name'] or ''}}</td>
  <td>{{r['difficulty'] or ''}}</td>
  <td>{{r['type'] or ''}}</td>
  <td>{{r['major_scale'] or ''}}</td>
</tr>
{% endfor %}
</table>
{% if page>1 %}<a href="?{{prev_qs}}">Prev</a>{% endif %}
{% if (page*per_page) < total %}<a href="?{{next_qs}}">Next</a>{% endif %}
</body></html>
"""

def create_app(db_path):
    app = Flask(__name__)
    def get_conn():
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        return conn

    @app.route("/")
    def index():
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("SELECT emotion_name FROM Emotions ORDER BY emotion_name")
        emotions = [r[0] for r in cur.fetchall()]

        composer = request.args.get("composer","").strip()
        emotion = request.args.get("emotion","").strip()
        min_d = request.args.get("min_d","").strip()
        typ = request.args.get("type","").strip()
        scale = request.args.get("scale","").strip()
        q = request.args.get("q","").strip()
        sort = request.args.get("sort","").strip()
        page = int(request.args.get("page", "1"))
        per_page = 50

        where = []
        params = []
        if composer:
            where.append("Composers.full_name LIKE ?")
            params.append(f"%{composer}%")
        if emotion:
            where.append("Emotions.emotion_name = ?")
            params.append(emotion)
        if min_d:
            try:
                md = int(min_d); where.append("difficulty >= ?"); params.append(md)
            except: pass
        if typ:
            where.append("Pieces.type LIKE ?"); params.append(f"%{typ}%")
        if scale:
            where.append("major_scale LIKE ?"); params.append(f"%{scale}%")
        if q:
            where.append("(Pieces.title LIKE ? OR Pieces.name LIKE ?)")
            params.extend([f"%{q}%", f"%{q}%"])
        where_sql = ("WHERE " + " AND ".join(where)) if where else ""
        sort_sql = ""
        if sort == "difficulty_desc": sort_sql = "ORDER BY difficulty DESC"
        elif sort == "difficulty_asc": sort_sql = "ORDER BY difficulty ASC"
        elif sort == "composer": sort_sql = "ORDER BY full_name"

        count_q = f"SELECT COUNT(*) FROM Pieces JOIN Composers ON Pieces.composer_id=Composers.composer_id LEFT JOIN Emotions ON Pieces.emotion_id=Emotions.emotion_id {where_sql}"
        cur.execute(count_q, params)
        total = cur.fetchone()[0]

        offset = (page-1)*per_page
        qry = f"""SELECT Pieces.*, Composers.full_name, Emotions.emotion_name
                  FROM Pieces JOIN Composers ON Pieces.composer_id=Composers.composer_id
                  LEFT JOIN Emotions ON Pieces.emotion_id=Emotions.emotion_id
                  {where_sql} {sort_sql} LIMIT ? OFFSET ?"""
        cur.execute(qry, params + [per_page, offset])
        rows = cur.fetchall()
        results = [dict(r) for r in rows]
        conn.close()

        from urllib.parse import urlencode
        base_q = {k:v for k,v in request.args.items() if k!="page"}
        prev_qs = urlencode({**base_q, "page": page-1})
        next_qs = urlencode({**base_q, "page": page+1})

        return render_template_string(FLASK_TEMPLATE, results=results, emotions=emotions, total=total, page=page, per_page=per_page, prev_qs=prev_qs, next_qs=next_qs, request=request)

    @app.route("/export")
    def export():
        conn = get_conn(); cur = conn.cursor()
        composer = request.args.get("composer","").strip()
        emotion = request.args.get("emotion","").strip()
        min_d = request.args.get("min_d","").strip()
        typ = request.args.get("type","").strip()
        scale = request.args.get("scale","").strip()
        q = request.args.get("q","").strip()

        where = []; params = []
        if composer: where.append("Composers.full_name LIKE ?"); params.append(f"%{composer}%")
        if emotion: where.append("Emotions.emotion_name = ?"); params.append(emotion)
        if min_d:
            try: md=int(min_d); where.append("difficulty >= ?"); params.append(md)
            except: pass
        if typ: where.append("Pieces.type LIKE ?"); params.append(f"%{typ}%")
        if scale: where.append("major_scale LIKE ?"); params.append(f"%{scale}%")
        if q: where.append("(Pieces.title LIKE ? OR Pieces.name LIKE ?)"); params.extend([f"%{q}%", f"%{q}%"])
        where_sql = ("WHERE " + " AND ".join(where)) if where else ""
        qry = f"""SELECT Pieces.piece_id, Pieces.title, Composers.full_name as composer, Emotions.emotion_name as emotion,
                         Pieces.difficulty, Pieces.type, Pieces.major_scale
                  FROM Pieces JOIN Composers ON Pieces.composer_id=Composers.composer_id
                  LEFT JOIN Emotions ON Pieces.emotion_id=Emotions.emotion_id
                  {where_sql}
               """
        cur.execute(qry, params)
        rows = cur.fetchall()
        import io, csv
        si = io.StringIO(); writer = csv.writer(si)
        writer.writerow(["piece_id","title","composer","emotion","difficulty","type","major_scale"])
        for r in rows: writer.writerow([r[0], r[1], r[2], r[3] or "", r[4] or "", r[5] or "", r[6] or ""])
        conn.close()
        return Response(si.getvalue(), mimetype="text/csv", headers={"Content-Disposition":"attachment;filename=music_export.csv"})

    return app

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=5000)
    args = ap.parse_args()
    app = create_app(args.db)
    print("Serving on http://%s:%d" % (args.host, args.port))
    app.run(host=args.host, port=args.port, debug=False)

if __name__ == "__main__":
    main()
