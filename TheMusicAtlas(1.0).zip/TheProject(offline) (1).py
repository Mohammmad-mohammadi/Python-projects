# music_menu_pretty.py
# Pretty TUI for your music DB using Rich (colors, borders, paging).
# No network. Reads music_ultimate_full.db and shows a nice table.

import os, sys, sqlite3, csv
DB_PATH = "music_ultimate_full.db"

# --- try Rich; fallback to plain if missing ---
try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.align import Align
    from rich.box import ROUNDED
    from rich.prompt import Prompt
    from rich.text import Text
    from rich import box
    HAVE_RICH = True
except Exception:
    HAVE_RICH = False

console = Console()

# ---------- Inline Help ----------
HELP_TEXT = """
[b]What is this?[/b]
An offline browser for your music database:
• Filter by composer, emotion, difficulty, nationality, key signature, and type.
• Page through results and export the current view to CSV.

[b]Quick start[/b]
1) Type [b]s[/b] to open the multi-filter form. Fill any fields you want.
2) Use [b]>[/b] and [b]<[/b] to move between pages. Change page size with [b]p[/b].
3) Type [b]x[/b] to export current results to CSV (e.g., music_export.csv).
4) Type [b]r[/b] to reset filters.

[b]Commands[/b]
[c] composer contains…        [e] select emotion (exact)
[d] minimum difficulty        [n] nationality contains…
[k] key signature contains…   [t] type contains…
[o] sort (difficulty_/composer)
[p] page size                 [s] multi-filter
[>] next page                 [<] previous page
[x] export CSV                [r] reset filters
[h] help                      [q] quit

[b]Examples[/b]
• Show hard Chopin etudes:  [i]c[/i] chopin, [i]t[/i] etude, [i]d[/i] 7, [i]o[/i] difficulty_desc
• Longing in minor keys:    [i]e[/i] Longing, [i]k[/i] minor
• French composers:         [i]n[/i] France (or “French” depending on data)
"""

def get_conn():
    if not os.path.exists(DB_PATH):
        print(f"[ERR] DB not found: {DB_PATH}")
        sys.exit(1)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def distinct(conn, sql):
    return [r[0] for r in conn.execute(sql).fetchall() if r[0]]

class Filters:
    def __init__(self):
        self.composer = None
        self.emotion = None
        self.min_diff = None
        self.nationality = None
        self.key_signature = None   # maps to Pieces.major_scale
        self.ptype = None
        self.sort = ""              # "", difficulty_desc, difficulty_asc, composer
        self.page = 1
        self.page_size = 12         # phone-friendly default
    def clear(self):
        self.__init__()
    def where_sql(self):
        where, params = [], []
        if self.composer:
            where.append("Composers.full_name LIKE ?"); params.append(f"%{self.composer}%")
        if self.emotion:
            where.append("Emotions.emotion_name = ?"); params.append(self.emotion)
        if self.min_diff is not None:
            where.append("Pieces.difficulty >= ?"); params.append(int(self.min_diff))
        if self.nationality:
            where.append("Composers.nationality LIKE ?"); params.append(f"%{self.nationality}%")
        if self.key_signature:
            where.append("Pieces.major_scale LIKE ?"); params.append(f"%{self.key_signature}%")
        if self.ptype:
            where.append("Pieces.type LIKE ?"); params.append(f"%{self.ptype}%")
        return ("WHERE " + " AND ".join(where)) if where else "", params
    def sort_sql(self):
        if self.sort == "difficulty_desc": return "ORDER BY Pieces.difficulty DESC"
        if self.sort == "difficulty_asc":  return "ORDER BY Pieces.difficulty ASC"
        if self.sort == "composer":        return "ORDER BY Composers.full_name"
        return ""

def fetch_page(conn, flt: Filters):
    where_sql, params = flt.where_sql()
    sort_sql = flt.sort_sql()
    total = conn.execute(f"""
        SELECT COUNT(*) FROM Pieces
        JOIN Composers ON Pieces.composer_id=Composers.composer_id
        LEFT JOIN Emotions ON Pieces.emotion_id=Emotions.emotion_id
        {where_sql}""", params).fetchone()[0]
    offset = (max(1, flt.page)-1)*flt.page_size
    rows = conn.execute(f"""
        SELECT Pieces.piece_id,
               COALESCE(Pieces.title, Pieces.name, '(untitled)') AS title,
               Pieces.type, Pieces.major_scale AS key_signature, Pieces.difficulty,
               Composers.full_name, Composers.nationality,
               Emotions.emotion_name
        FROM Pieces
        JOIN Composers ON Pieces.composer_id=Composers.composer_id
        LEFT JOIN Emotions ON Pieces.emotion_id=Emotions.emotion_id
        {where_sql} {sort_sql}
        LIMIT ? OFFSET ?""", params+[flt.page_size, offset]).fetchall()
    return rows, total

def export_current(conn, flt: Filters, out_path="music_export.csv"):
    where_sql, params = flt.where_sql()
    sort_sql = flt.sort_sql()
    rows = conn.execute(f"""
        SELECT Pieces.piece_id,
               COALESCE(Pieces.title, Pieces.name, '') AS title,
               Composers.full_name AS composer, Composers.nationality,
               Emotions.emotion_name AS emotion,
               Pieces.difficulty, Pieces.type, Pieces.major_scale AS key_signature
        FROM Pieces
        JOIN Composers ON Pieces.composer_id=Composers.composer_id
        LEFT JOIN Emotions ON Pieces.emotion_id=Emotions.emotion_id
        {where_sql} {sort_sql}""", params).fetchall()
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["piece_id","title","composer","nationality","emotion","difficulty","type","key_signature"])
        for r in rows:
            w.writerow([r["piece_id"], r["title"], r["composer"] or "", r["nationality"] or "",
                        r["emotion"] or "", r["difficulty"] or "", r["type"] or "", r["key_signature"] or ""])
    return len(rows)

def clear():
    os.system("cls" if os.name=="nt" else "clear")

def show_screen(conn, flt: Filters, emotions, types, keys, nations):
    rows, total = fetch_page(conn, flt)
    shown = len(rows)
    clear()
    # Header panel
    if HAVE_RICH:
        header = Table.grid(expand=True)
        header.add_column(justify="left")
        header.add_row(Text("🎼 Music Atlas — Offline", style="bold cyan"))
        console.print(Panel(header, box=ROUNDED, border_style="cyan"))
        # Filters panel
        ftxt = (
            f"[b]composer[/b]={flt.composer or '—'}  "
            f"[b]emotion[/b]={flt.emotion or '—'}  "
            f"[b]min_d[/b]={flt.min_diff or '—'}  "
            f"[b]nationality[/b]={flt.nationality or '—'}  "
            f"[b]key[/b]={flt.key_signature or '—'}  "
            f"[b]type[/b]={flt.ptype or '—'}  "
            f"[b]sort[/b]={flt.sort or '—'}"
        )
        console.print(Panel(ftxt, title="Active filters", box=ROUNDED, border_style="magenta"))
        # Table (no-wrap + ellipsis for phone screens)
        table = Table(
            box=box.SIMPLE_HEAVY, show_edge=True, header_style="bold white on blue", pad_edge=False
        )
        table.add_column("ID", width=4, justify="right", no_wrap=True)
        table.add_column("Title", width=26, no_wrap=True, overflow="ellipsis")
        table.add_column("Composer", width=18, no_wrap=True, overflow="ellipsis")
        table.add_column("Nat.", width=8, no_wrap=True, overflow="ellipsis")
        table.add_column("Emotion", width=10, no_wrap=True, overflow="ellipsis")
        table.add_column("d", width=2, justify="right", no_wrap=True)
        table.add_column("Type", width=12, no_wrap=True, overflow="ellipsis")
        table.add_column("Key", width=12, no_wrap=True, overflow="ellipsis")
        for r in rows:
            table.add_row(
                str(r["piece_id"]),
                r["title"] or "",
                r["full_name"] or "",
                r["nationality"] or "",
                r["emotion_name"] or "",
                str(r["difficulty"] or ""),
                r["type"] or "",
                r["key_signature"] or "",
            )
        subtitle = Text(f"{shown} shown of {total} • Page {flt.page} • Page size {flt.page_size}", style="dim")
        console.print(table)
        console.print(Align.center(subtitle))
        # Commands
        help_txt = (
            "[b][s][/b] search   [b][c][/b] composer   [b][e][/b] emotion   [b][d][/b] min diff   "
            "[b][n][/b] nationality   [b][k][/b] key   [b][t][/b] type   [b][o][/b] sort   "
            "[b][p][/b] page size   [b][>][/b] next   [b][<][/b] prev   "
            "[b][x][/b] export CSV   [b][r][/b] reset   [b][h][/b] help   [b][q][/b] quit"
        )
        console.print(Panel(help_txt, title="Commands", box=ROUNDED, border_style="green"))
    else:
        print("Music Atlas — Offline")
        print(f"Filters: composer={flt.composer} emotion={flt.emotion} min_d={flt.min_diff} "
              f"nationality={flt.nationality} key={flt.key_signature} type={flt.ptype} sort={flt.sort}")
        print(f"{shown} shown of {total} • Page {flt.page} • Page size {flt.page_size}")
        print("-"*100)
        print(f"{'ID':>4} | {'Title':30} | {'Composer':20} | {'Nat.':6} | {'Emotion':10} | d | {'Type':10} | {'Key':10}")
        print("-"*100)
        for r in rows:
            print(f"{r['piece_id']:>4} | {str(r['title'])[:30]:30} | {str(r['full_name'])[:20]:20} | "
                  f"{str(r['nationality'] or '')[:6]:6} | {str(r['emotion_name'] or '')[:10]:10} | "
                  f"{str(r['difficulty'] or ''):>1} | {str(r['type'] or '')[:10]:10} | {str(r['key_signature'] or '')[:10]:10}")
        print("-"*100)
        print("s/c/e/d/n/k/t/o/p/>/</x/r/h/q")

def main():
    conn = get_conn()
    flt = Filters()

    # Startup tip
    if HAVE_RICH:
        console.print(Panel(Text("Tip: type [b]h[/b] anytime for help.", style="bold cyan"),
                            title="Welcome", box=ROUNDED, border_style="cyan"))
    else:
        print("Tip: type 'h' anytime for help.")

    emotions = distinct(conn, "SELECT emotion_name FROM Emotions ORDER BY emotion_name")
    types    = distinct(conn, "SELECT DISTINCT type FROM Pieces WHERE type IS NOT NULL AND type<>'' ORDER BY type")
    keys     = distinct(conn, "SELECT DISTINCT major_scale FROM Pieces WHERE major_scale IS NOT NULL AND major_scale<>'' ORDER BY major_scale")
    nations  = distinct(conn, "SELECT DISTINCT nationality FROM Composers WHERE nationality IS NOT NULL AND nationality<>'' ORDER BY nationality")

    while True:
        show_screen(conn, flt, emotions, types, keys, nations)
        try:
            cmd = Prompt.ask("cmd").strip().lower() if HAVE_RICH else input("cmd: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            break

        if cmd == "q":
            break
        elif cmd == "":
            continue
        elif cmd == "h":
            if HAVE_RICH:
                console.print(Panel(HELP_TEXT, title="Help", box=ROUNDED, border_style="yellow"))
                Prompt.ask("Press Enter to continue", default="")
            else:
                print(HELP_TEXT); input("Enter to continue…")
        elif cmd == "s":  # quick multi-filter
            if HAVE_RICH:
                comp = Prompt.ask("composer contains", default=flt.composer or "")
                emo  = Prompt.ask("emotion (exact)", default=flt.emotion or "")
                mind = Prompt.ask("min difficulty", default=str(flt.min_diff or ""))
                key  = Prompt.ask("key contains", default=flt.key_signature or "")
                typ  = Prompt.ask("type contains", default=flt.ptype or "")
                nat  = Prompt.ask("nationality contains", default=flt.nationality or "")
            else:
                comp = input("composer contains: ") or flt.composer or ""
                emo  = input("emotion (exact): ") or flt.emotion or ""
                mind = input("min difficulty: ") or (flt.min_diff or "")
                key  = input("key contains: ") or flt.key_signature or ""
                typ  = input("type contains: ") or flt.ptype or ""
                nat  = input("nationality contains: ") or flt.nationality or ""
            flt.composer = comp or None
            flt.emotion = emo or None
            flt.min_diff = int(mind) if str(mind).isdigit() else None
            flt.key_signature = key or None
            flt.ptype = typ or None
            flt.nationality = nat or None
            flt.page = 1
        elif cmd == "c":
            flt.composer = (Prompt.ask("composer contains (blank=clear)").strip() if HAVE_RICH
                            else input("composer contains: ").strip()) or None
            flt.page = 1
        elif cmd == "e":
            (console.print(f"emotions: {', '.join(emotions)}") if HAVE_RICH else print(emotions))
            v = Prompt.ask("emotion (exact; blank=clear)").strip() if HAVE_RICH else input("emotion: ").strip()
            flt.emotion = v or None; flt.page = 1
        elif cmd == "d":
            v = Prompt.ask("minimum difficulty (int; blank=clear)").strip() if HAVE_RICH else input("min diff: ").strip()
            flt.min_diff = int(v) if v.isdigit() else None; flt.page = 1
        elif cmd == "n":
            (console.print(f"some nationalities: {', '.join(nations[:20])} …") if HAVE_RICH else print(nations[:20]))
            v = Prompt.ask("nationality contains (blank=clear)").strip() if HAVE_RICH else input("nationality: ").strip()
            flt.nationality = v or None; flt.page = 1
        elif cmd == "k":
            (console.print(f"some keys: {', '.join(keys[:25])} …") if HAVE_RICH else print(keys[:25]))
            v = Prompt.ask("key signature contains (e.g., C major; blank=clear)").strip() if HAVE_RICH else input("key: ").strip()
            flt.key_signature = v or None; flt.page = 1
        elif cmd == "t":
            (console.print(f"common types: {', '.join(types[:25])} …") if HAVE_RICH else print(types[:25]))
            v = Prompt.ask("type contains (blank=clear)").strip() if HAVE_RICH else input("type: ").strip()
            flt.ptype = v or None; flt.page = 1
        elif cmd == "o":
            v = Prompt.ask("sort (difficulty_desc / difficulty_asc / composer / blank)").strip() if HAVE_RICH else input("sort: ").strip()
            flt.sort = v if v in ("difficulty_desc","difficulty_asc","composer") else ""; flt.page = 1
        elif cmd == "p":
            v = Prompt.ask(f"page size (current {flt.page_size})").strip() if HAVE_RICH else input(f"page size (current {flt.page_size}): ").strip()
            if v.isdigit() and int(v) > 0: flt.page_size = int(v); flt.page = 1
        elif cmd == ">":
            _, total = fetch_page(conn, flt)
            if flt.page * flt.page_size < total: flt.page += 1
        elif cmd == "<":
            if flt.page > 1: flt.page -= 1
        elif cmd == "x":
            out = Prompt.ask("CSV filename (default music_export.csv)").strip() if HAVE_RICH else input("CSV filename: ").strip()
            out = out or "music_export.csv"
            n = export_current(conn, flt, out)
            if HAVE_RICH: console.print(f"[green][ok][/green] Exported {n} rows → {out}")
            else: print(f"[ok] Exported {n} rows → {out}")
            if HAVE_RICH: Prompt.ask("Press Enter to continue", default="")
            else: input("Enter to continue…")
        elif cmd == "r":
            flt.clear()
        else:
            if HAVE_RICH: console.print("[red]Unknown command[/red]")
            else: print("Unknown command.")
    conn.close()
    if HAVE_RICH: console.print("[cyan]Bye.[/cyan]")
    else: print("Bye.")

if __name__ == "__main__":
    main()