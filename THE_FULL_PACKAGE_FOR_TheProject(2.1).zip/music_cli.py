#!/usr/bin/env python3
# Simple music CLI (list/find/export) — lightweight
import sqlite3, sys, csv
from pathlib import Path

DB = Path(__file__).resolve().parent / "music_plus.db"

def conn():
    return sqlite3.connect(DB)

def list_pieces(limit=30):
    with conn() as c:
        rows = c.execute("""SELECT p.piece_id, p.name, p.title, c.full_name, p.era, p.major_scale, p.difficulty
                            FROM Pieces p JOIN Composers c ON p.composer_id=c.composer_id
                            ORDER BY c.full_name LIMIT ?;""", (limit,)).fetchall()
    for r in rows:
        print(f"{r[0]:3} | {r[2] or ''} ({r[1]}) — {r[3]} — {r[4]} — {r[6]}")

def find_by_composer(name):
    with conn() as c:
        rows = c.execute("""SELECT p.piece_id, p.title, p.name, p.era, p.difficulty
                            FROM Pieces p JOIN Composers c ON p.composer_id=c.composer_id
                            WHERE c.full_name LIKE ? LIMIT 200;""", (f"%{name}%",)).fetchall()
    for r in rows:
        print(f"{r[0]:3} | {r[1] or ''} ({r[2]}) — {r[3]} — {r[4]}")

def export_csv(path, limit=500):
    with conn() as c, open(path, "w", newline="", encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["piece_id","title","name","composer","era","scale","difficulty"])
        rows = c.execute("""SELECT p.piece_id, p.title, p.name, c.full_name, p.era, p.major_scale, p.difficulty
                            FROM Pieces p JOIN Composers c ON p.composer_id=c.composer_id ORDER BY p.piece_id LIMIT ?;""", (limit,)).fetchall()
        for r in rows: w.writerow(r)

def help_msg():
    print("Usage: python music_cli.py [list N] [find composer_name] [export path]")

if __name__=="__main__":
    if len(sys.argv)<2:
        help_msg(); sys.exit(0)
    cmd = sys.argv[1]
    if cmd=="list":
        n = int(sys.argv[2]) if len(sys.argv)>2 else 30; list_pieces(n)
    elif cmd=="find":
        name = " ".join(sys.argv[2:]); find_by_composer(name)
    elif cmd=="export":
        path = sys.argv[2] if len(sys.argv)>2 else "export.csv"; export_csv(path)
    else:
        help_msg()
