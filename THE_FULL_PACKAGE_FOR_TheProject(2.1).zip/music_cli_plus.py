#!/usr/bin/env python3
# music_cli_plus.py — Extended CLI with DB bootstrap & scale drawing
from pathlib import Path
import sqlite3, sys, random, csv
HERE = Path(__file__).resolve().parent
DB = HERE / "music_plus.db"
SEED = HERE / "music_database_full_no_tx.sql"

def ensure_db():
    if DB.exists():
        return
    if not SEED.exists():
        raise FileNotFoundError("Seed SQL missing: " + str(SEED))
    sql = SEED.read_text(encoding="utf-8")
    conn = sqlite3.connect(DB); conn.executescript(sql); conn.commit(); conn.close()
    print("DB created from seed.")

def conn():
    return sqlite3.connect(DB)

def boost(target_composers=100, target_pieces=500):
    ensure_db()
    FIRSTS = ["Luca","Elena","Noah","Maya","Arman","Nilou","Sofia","Leo","Anya","Mateo","Clara","Hiro","Yuna","Omar","Layla"]
    LASTS = ["Novak","Farhani","Rossi","Keller","Amini","Kato","Bianchi","Silva","Petrov","Haddad","Moreau","Gruber"]
    ERAS = ["Baroque","Classical","Romantic","20th Century","Contemporary"]
    KEYS = ["C","G","D","A","E","B","F#","Db","Ab","Eb","Bb","F"]
    TYPES = ["etude","prelude","fugue","toccata","impromptu","ballade","nocturne","waltz"]
    with conn() as c:
        # emotions table ensure
        try:
            c.execute("SELECT COUNT(*) FROM Emotions;").fetchone()
        except sqlite3.Error:
            c.execute("CREATE TABLE IF NOT EXISTS Emotions(emotion_id INTEGER PRIMARY KEY, emotion_name TEXT UNIQUE);")
        em = ["Tranquility","Melancholy","Tension","Triumph","Longing"]
        for i,e in enumerate(em, start=1):
            c.execute("INSERT OR IGNORE INTO Emotions(emotion_id, emotion_name) VALUES(?,?);",(i,e))
        # composers
        cur = c.execute("SELECT COUNT(*) FROM Composers;").fetchone()[0]
        while cur < target_composers:
            nm = random.choice(FIRSTS)+" "+random.choice(LASTS)
            era = random.choice(ERAS); nat = random.choice(["Italian","French","German","Iranian","Japanese","Polish"])
            inst = random.choice(["piano","violin","cello","guitar"])
            c.execute("INSERT INTO Composers(full_name, era, nationality, main_instrument) VALUES(?,?,?,?);",(nm,era,nat,inst))
            cur += 1
        conn_comp = [r[0] for r in c.execute("SELECT composer_id FROM Composers;").fetchall()]
        # pieces
        curp = c.execute("SELECT COUNT(*) FROM Pieces;").fetchone()[0]
        while curp < target_pieces:
            comp = random.choice(conn_comp)
            name = f"Op.{random.randint(1,120)} No.{random.randint(1,40)}"
            title = random.choice(["Étude","Nocturne","Prelude","Fugue","Toccata"]) + " in " + random.choice(KEYS)
            era = c.execute("SELECT era FROM Composers WHERE composer_id=?",(comp,)).fetchone()[0]
            scale = random.choice(KEYS) + (" minor" if random.random()<0.5 else " major")
            diff = random.randint(1,10)
            emo_id = random.randint(1,5)
            typ = random.choice(TYPES)
            c.execute("INSERT INTO Pieces(name,title,composer_id,era,major_scale,difficulty,emotion_id,type) VALUES(?,?,?,?,?,?,?,?);",
                      (name,title,comp,era,scale,diff,emo_id,typ))
            curp += 1
        c.commit()
    print(f"Boost complete. Composers >= {target_composers}, Pieces >= {target_pieces}.")

# Simple scale builder (returns set of semitone indices)
NOTE_ORDER = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]
SCALES = {
    "major":[0,2,4,5,7,9,11],
    "natural_minor":[0,2,3,5,7,8,10],
    "harmonic_minor":[0,2,3,5,7,8,11],
    "melodic_minor":[0,2,3,5,7,9,11],
    "pentatonic_major":[0,2,4,7,9],
    "pentatonic_minor":[0,3,5,7,10],
}

def norm(n):
    return {"Db":"C#","Eb":"D#","Gb":"F#","Ab":"G#","Bb":"A#"}.get(n,n)

def build_scale(tonic, scale_type, octaves=2):
    tonic = norm(tonic)
    if scale_type not in SCALES:
        raise ValueError("Unknown scale")
    root = NOTE_ORDER.index(tonic)
    pattern = SCALES[scale_type]
    notes = []
    for o in range(octaves):
        base = root + 12*o
        for step in pattern:
            notes.append((base+step)%12)
    return sorted(set(notes))

def draw_scale(tonic, scale_type, outfile):
    try:
        import matplotlib.pyplot as plt
    except Exception as e:
        print("matplotlib required for drawing:", e); return
    notes = build_scale(tonic, scale_type, octaves=2)
    # draw simple keyboard highlighting notes
    white = [0,2,4,5,7,9,11]
    key_w = 1; key_h = 3; black_w=0.6; black_h=2.0
    total_whites = 7*2
    fig, ax = plt.subplots(figsize=(total_whites*0.5,3))
    x = 0
    order = []
    for o in range(2):
        for i in range(12):
            if i in white:
                # white key
                idx = i + 12*o
                in_scale = (idx%12) in notes
                rect = plt.Rectangle((x,0), key_w, key_h, facecolor="white" if not in_scale else "#ffd", edgecolor="black")
                ax.add_patch(rect)
                order.append((idx,x,"white",in_scale))
                x += key_w
            else:
                # black keys placed between whites; draw later
                order.append((i+12*o,x-0.5,"black", (i%12 in notes)))
    for idx, xpos, kind, highlight in order:
        if kind=="black":
            rect = plt.Rectangle((xpos-0.3, key_h-black_h), black_w, black_h, facecolor="black" if not highlight else "#555")
            ax.add_patch(rect)
    ax.set_xlim(-0.5, total_whites*key_w+0.5); ax.set_ylim(0, key_h+0.2); ax.axis("off")
    ax.set_title(f"{tonic} {scale_type.replace('_',' ')}")
    fig.tight_layout(); fig.savefig(outfile, dpi=160); plt.close(fig)
    print("Wrote", outfile)

def help_msg():
    print("Usage: music_cli_plus.py [boost] [scale TONIC SCALETYPE OUTFILE]")

if __name__=="__main__":
    if len(sys.argv)<2:
        help_msg(); sys.exit(0)
    cmd = sys.argv[1]
    if cmd=="boost":
        boost(); sys.exit(0)
    if cmd=="scale" and len(sys.argv)>=5:
        tonic, stype, out = sys.argv[2], sys.argv[3], sys.argv[4]; ensure_db(); draw_scale(tonic, stype, out); sys.exit(0)
    help_msg()
